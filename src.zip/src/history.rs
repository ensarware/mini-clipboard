use parking_lot::RwLock;
use std::sync::Arc;

const MAX_HISTORY: usize = 100;

#[derive(Clone)]
pub struct HistoryManager {
    entries: Arc<RwLock<Vec<String>>>,
}

impl HistoryManager {
    pub fn new(initial_entries: Vec<String>) -> Self {
        Self {
            entries: Arc::new(RwLock::new(initial_entries)),
        }
    }

    pub fn add(&self, text: String) -> bool {
        let mut lock = self.entries.write();
        
        // Son elemanla aynıysa ekleme (ardışık tekrar kontrolü)
        if let Some(last) = lock.first() {
            if last == &text {
                return false;
            }
        }

        // Yeni metni en başa ekle
        lock.insert(0, text);

        // 100'ü geçerse sondakileri kırp
        if lock.len() > MAX_HISTORY {
            lock.truncate(MAX_HISTORY);
        }
        
        true
    }

    pub fn get_all(&self) -> Vec<String> {
        self.entries.read().clone()
    }
}