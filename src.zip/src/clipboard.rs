use arboard::Clipboard;
use std::thread;
use std::time::Duration;

use crate::history::HistoryManager;
use crate::storage;
use crate::error::Result;

pub fn spawn_listener(history: HistoryManager) {
    thread::spawn(move || {
        // Pano nesnesini oluştur
        let mut ctx = match Clipboard::new() {
            Ok(c) => c,
            Err(_) => return, // Hata varsa thread biter
        };
        
        let mut last_text = String::new();

        loop {
            if let Ok(text) = ctx.get_text() {
                let text = text.trim().to_string();
                if !text.is_empty() && text != last_text {
                    if history.add(text.clone()) {
                        last_text = text;
                        // Yeni metin eklendiğinde diske kaydet
                        let _ = storage::save_history(&history.get_all());
                    }
                }
            }
            // CPU'yu yormamak için yarım saniye bekle
            thread::sleep(Duration::from_millis(500));
        }
    });
}

pub fn set_clipboard_text(text: &str) -> Result<()> {
    let mut ctx = Clipboard::new().map_err(|e| anyhow::anyhow!(e.to_string()))?;
    ctx.set_text(text).map_err(|e| anyhow::anyhow!(e.to_string()))?;
    Ok(())
}