use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;

use eframe::egui;
use crate::history::HistoryManager;

pub struct ClipboardApp {
    history: HistoryManager,
    show_flag: Arc<AtomicBool>,
    search_query: String,
}

impl ClipboardApp {
    pub fn new(history: HistoryManager, show_flag: Arc<AtomicBool>) -> Self {
        Self {
            history,
            show_flag,
            search_query: String::new(),
        }
    }
}

impl eframe::App for ClipboardApp {
    // &self yerine &mut self olarak güncellendi, gereksiz import kaldırıldı
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        // Hotkey basıldıysa pencereyi göster
        if self.show_flag.swap(false, Ordering::Relaxed) {
            ctx.send_viewport_cmd(egui::ViewportCommand::Visible(true));
            ctx.send_viewport_cmd(egui::ViewportCommand::Focus);
        }

        // ESC'ye basılırsa pencereyi gizle
        if ctx.input(|i| i.key_pressed(egui::Key::Escape)) {
            ctx.send_viewport_cmd(egui::ViewportCommand::Visible(false));
            self.search_query.clear();
        }

        egui::CentralPanel::default().show(ctx, |ui| {
            crate::ui::render_ui(ui, &self.history, &mut self.search_query, ctx);
        });
        
        // Ekranda değişiklik olmadığında CPU'yu dinlendirmek için saniyede 10 kez tetikle
        ctx.request_repaint_after(std::time::Duration::from_millis(100));
    }
}