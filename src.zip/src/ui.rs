use eframe::egui;
use crate::history::HistoryManager;
use crate::clipboard;

pub fn render_ui(
    ui: &mut egui::Ui,
    history: &HistoryManager,
    search_query: &mut String,
    ctx: &egui::Context,
) {
    ui.heading("📋 Pano Geçmişi");
    
    // Arama kutusu
    let search_response = ui.text_edit_singleline(search_query);
    search_response.request_focus(); // Açılır açılmaz yazı yazabilmek için

    ui.separator();

    let all_entries = history.get_all();
    
    // Arama filtresi
    let filtered: Vec<&String> = all_entries
        .iter()
        .filter(|t| t.to_lowercase().contains(&search_query.to_lowercase()))
        .collect();

    if filtered.is_empty() {
        ui.label(egui::RichText::new("Sonuç bulunamadı.").color(egui::Color32::GRAY));
        return;
    }

    // Scroll edilebilir liste
    egui::ScrollArea::vertical().show(ui, |ui| {
        for text in filtered {
            // Metin çok uzunsa kırpıyoruz
            let display_text = if text.len() > 60 {
                format!("{}...", &text[..60].replace('\n', " "))
            } else {
                text.replace('\n', " ")
            };

            let response = ui.add(
                egui::Label::new(display_text).sense(egui::Sense::click())
            );

            // Hover efekti (üzerine gelince fare imleci değişir)
            if response.hovered() {
                ui.ctx().set_cursor_icon(egui::CursorIcon::PointingHand);
            }

            // Çift tıklanırsa panoya kopyala ve pencereyi gizle
            if response.double_clicked() {
                let _ = clipboard::set_clipboard_text(text);
                ctx.send_viewport_cmd(egui::ViewportCommand::Visible(false));
            }
        }
    });
}