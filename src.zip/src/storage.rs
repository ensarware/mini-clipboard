use std::env;
use std::fs::{self, File};
use std::io::{BufReader, BufWriter};
use std::path::PathBuf;

use crate::error::Result;

const FOLDER_NAME: &str = "MiniClipboard";
const FILE_NAME: &str = "history.json";

fn get_file_path() -> Result<PathBuf> {
    let appdata = env::var("APPDATA").unwrap_or_else(|_| ".".to_string());
    let mut path = PathBuf::from(appdata);
    path.push(FOLDER_NAME);
    
    if !path.exists() {
        fs::create_dir_all(&path)?;
    }
    
    path.push(FILE_NAME);
    Ok(path)
}

pub fn load_history() -> Result<Vec<String>> {
    let path = get_file_path()?;
    if !path.exists() {
        return Ok(Vec::new());
    }

    let file = File::open(path)?;
    let reader = BufReader::new(file);
    let history: Vec<String> = serde_json::from_reader(reader)?;
    Ok(history)
}

pub fn save_history(history: &[String]) -> Result<()> {
    let path = get_file_path()?;
    let file = File::create(path)?;
    let writer = BufWriter::new(file);
    serde_json::to_writer_pretty(writer, history)?;
    Ok(())
}   