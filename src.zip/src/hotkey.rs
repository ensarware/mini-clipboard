use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::thread;

use windows::Win32::Foundation::HWND;
use windows::Win32::UI::Input::KeyboardAndMouse::{
    RegisterHotKey, MOD_CONTROL, MOD_SHIFT,
};
use windows::Win32::UI::WindowsAndMessaging::{GetMessageW, MSG, WM_HOTKEY};

pub fn spawn_hotkey_listener(show_flag: Arc<AtomicBool>) {
    thread::spawn(move || unsafe {
        // windows 0.58 sürümünde VIRTUAL_KEY yerine doğrudan u32 bekleniyor.
        // Ayrıca HWND(std::ptr::null_mut()) yerine HWND::default() kullanmak daha güvenli.
        let result = RegisterHotKey(
            HWND::default(),
            1,
            MOD_CONTROL | MOD_SHIFT,
            0x56, // 'V' tuşunun onaltılık kodu
        );

        if result.is_ok() {
            let mut msg = MSG::default();
            // GetMessageW BOOL döner, .as_bool() ile güvenli kontrol edilir.
            while GetMessageW(&mut msg, HWND::default(), 0, 0).as_bool() {
                if msg.message == WM_HOTKEY {
                    show_flag.store(true, Ordering::Relaxed);
                }
            }
        }
    });
}