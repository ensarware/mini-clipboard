#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod error;
mod storage;
mod history;
mod clipboard;
mod hotkey;
mod ui;
mod app;

use std::sync::atomic::AtomicBool;
use std::sync::Arc;
use eframe::egui;

use history::HistoryManager;
use storage::load_history;

fn main() -> eframe::Result<()> {
    // 1. Önceki kayıtları disken yükle, yoksa boş başlat
    let loaded_history = load_history().unwrap_or_default();
    let history_manager = HistoryManager::new(loaded_history);

    // 2. Panoyu arka planda dinleyecek thread'i başlat
    clipboard::spawn_listener(history_manager.clone());

    // 3. CTRL + SHIFT + V dinleyicisini başlat
    let show_flag = Arc::new(AtomicBool::new(false));
    hotkey::spawn_hotkey_listener(Arc::clone(&show_flag));

    // 4. Pencere ayarları
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([350.0, 450.0])
            .with_resizable(false)
            .with_always_on_top()
            .with_visible(false) // İlk başta arka planda gizli kalmasını sağlar
            .with_title("Mini Clipboard"),
        run_and_return: false,
        ..Default::default()
    };

    // 5. GUI uygulamasını başlat
    eframe::run_native(
        "Mini Clipboard",
        options,
        Box::new(|cc| {
            cc.egui_ctx.set_visuals(egui::Visuals::dark());
            Ok(Box::new(app::ClipboardApp::new(history_manager, show_flag)))
        }),
    )
}